﻿namespace SLABInProcApp
{
    using System.Diagnostics.Tracing;

    [EventSource(Name = "ApplicationEventSourceFormatting")]
    public sealed class ApplicationEventSource : EventSource
    {
        public static ApplicationEventSource Log = new ApplicationEventSource();

        #region Inner Types

        public class Keywords
        {
            public const EventKeywords Database = (EventKeywords)1;
            public const EventKeywords Component = (EventKeywords)2;
        }

        public class Tasks
        {
            public const EventTask PasswordHashing = (EventTask)1;
            public const EventTask Load = (EventTask)2;
        }

        #endregion Inner Types

        #region Logging Methods

        [Event(
            1,
            Keywords = Keywords.Database,
            Message = "Password hashing request for user: {1}, Request Id: {0}",
            Task = Tasks.PasswordHashing,
            Opcode = EventOpcode.Start,
            Level = EventLevel.Informational)]
        public void RequestPasswordHashing(int req, string userName)
        {
            WriteEvent(1, req, userName);
        }

        [Event(2,
            Keywords = Keywords.Component,
            Message = "Component: {2} not successfully loaded for user: {0} on machine: {1}",
            Task = Tasks.Load,
            Opcode = EventOpcode.Start,
            Level = EventLevel.Error)]
        public void ComponentNotLoaded(string userName, string machineName, string componentName)
        {
            WriteEvent(2, userName, machineName, componentName);
        }

        #endregion Logging Methods
    }
}
