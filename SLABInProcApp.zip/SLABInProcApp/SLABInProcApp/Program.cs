﻿
namespace SLABInProcApp
{
    using Microsoft.Practices.EnterpriseLibrary.SemanticLogging;
    using System;
    using System.Diagnostics.Tracing;

    class Program
    {
        static void Main(string[] args)
        {
            //var eventListener = new ObservableEventListener();

            //eventListener.EnableEvents(
            //    ApplicationEventSource.Log,
            //    EventLevel.LogAlways,
            //    Keywords.All);

            //eventListener.Subscribe(new ObserverE());

            
            var eventListener = ConsoleLog.CreateListener() as ObservableEventListener ??
                                        new ObservableEventListener();

            eventListener.EnableEvents(
                ApplicationEventSource.Log,
                EventLevel.LogAlways,
                Keywords.All);

            //// Subscription to Console Sink
            //eventListener.LogToConsole();

            eventListener.Subscribe(new CustomObserver());

            //eventListener.LogToConsole();

            // Subscription with SQL Server Sink
            eventListener.LogToSqlDatabase(
                @"(localdb)\v11.0",
                @"Data Source=(localdb)\v11.0;Initial Catalog=Logging;Integrated Security=True;Connect Timeout=15;Encrypt=False;TrustServerCertificate=False");

            // Subscription with Windows Azure Table Service
            eventListener.LogToWindowsAzureTable(
                "azureSink",
                "UseDevelopmentStorage=true;",
                "SLAB");

            // Log
            ApplicationEventSource.Log.ComponentNotLoaded("muhammad", "Cheeta", "Core");
            ApplicationEventSource.Log.RequestPasswordHashing(1, "muhammad");
            
            // Wait for key pressed
            Console.ReadLine();
        }
    }


    public class CustomObserver : IObserver<EventEntry>
    {
        public void OnCompleted()
        {
            Console.WriteLine("OnComplete");
        }

        public void OnError(Exception error)
        {
            Console.WriteLine(error.Message);
        }

        public void OnNext(EventEntry value)
        {
            Console.WriteLine(value.FormattedMessage);
        }
    }
}
