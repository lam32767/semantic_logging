﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Tracing;
using System.Reactive;
using System.Reactive.Linq;
using Microsoft.Practices.EnterpriseLibrary.SemanticLogging;

//using EventLevel = System.Diagnostics.Eventing.Reader.EventLevel;

namespace LoggingEx
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Test2(args);

            MyEventSource.Log.WriteLog("message logged");
            MyEventSource.Log.WriteLog("Another Message");

            //Console.ReadLine();
            //ObservableEventSource 
            //ConsoleLog.LogToConsole()
        }

        private static void Test2(string[] args)
        {
            var listener = new ObservableEventListener();
            listener.EnableEvents(MyEventSource.Log, EventLevel.Informational);

            listener.Subscribe<EventEntry>(
                                a => Debug.WriteLine(a.Payload[0]),
                                e => Debug.WriteLine(e.Message),
                                () => Debug.WriteLine("Completed!"));

            Console.ReadLine();
        }

        static void TestMethod(string[] args)
        {
            var listener = new MyEventListener();
            listener.EnableEvents(MyEventSource.Log, EventLevel.Informational);
            
            MyEventSource.Log.WriteLog("message logged");

            Console.ReadLine();
        }
    }

    internal class MyEventListener : EventListener
    {
        protected override void OnEventSourceCreated(EventSource eventSource)
        {
            base.OnEventSourceCreated(eventSource);

            Debug.WriteLine("Listener attached to the source");
        }

        protected override void OnEventWritten(EventWrittenEventArgs eventData)
        {
            Debug.WriteLine("Event data: {0}", eventData.Payload[0]);
        }
    }
}
