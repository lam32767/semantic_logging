﻿using System.Diagnostics.Tracing;

namespace LoggingEx
{
    [EventSource(Name = "Microsoft-SemanticLogging")]
    public sealed class MyEventSource : EventSource
    {
        public static MyEventSource Log = new MyEventSource();

        //[Event(2, Message = "ImportantMessage: {0}", Level = EventLevel.Informational, Keywords = (EventKeywords)3, Opcode = System.Diagnostics.Tracing.EventOpcode.Info)]
        //[Event(2, Message = "ImportantMessage: {0}")]
        public void WriteLog(string message)
        {
            this.WriteEvent(1, message);
        }
    }
}