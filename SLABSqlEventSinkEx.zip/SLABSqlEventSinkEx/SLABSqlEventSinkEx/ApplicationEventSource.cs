﻿
namespace SLABSqlEventSinkEx
{
    using System.Diagnostics.Tracing;

    [EventSource(Name = "SqlApplicationEventSource")]
    public sealed class ApplicationEventSource : EventSource
    {
        public static ApplicationEventSource Log = new ApplicationEventSource();

        #region Inner Types

        public class Keywords
        {
            public const EventKeywords Database = (EventKeywords)1;
            //public const EventKeywords Database = (EventKeywords)1;
        }

        public class Tasks
        {
            public const EventTask PasswordHashing = (EventTask)0x1;
        }

        #endregion Inner Types

        #region Logging Methods

        [Event(
            1, 
            Keywords = Keywords.Database, 
            Message = "Start processing request Database - {0}", 
            Task = Tasks.PasswordHashing, 
            Opcode = EventOpcode.Start,
            Level = EventLevel.Informational)]
        public void RequestPasswordHashing(int req)
        {
            WriteEvent(1, req);
        }

        #endregion Logging Methods
    }
}