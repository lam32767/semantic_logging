﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Tracing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Practices.EnterpriseLibrary.SemanticLogging;

namespace SLABSqlEventSinkEx
{
    class Program
    {
       private static void Main(string[] args)
        {
            var sqlDatabaseListener =
                SqlDatabaseLog.CreateListener(
                    @"(localdb)\v11.0",
                    "Data Source=(localdb)\v11.0;Initial Catalog=Logging;Integrated Security=True;Connect Timeout=15;Encrypt=False;TrustServerCertificate=False");

            sqlDatabaseListener.EnableEvents(ApplicationEventSource.Log, EventLevel.Informational, Keywords.All);

            ApplicationEventSource.Log.RequestPasswordHashing(10010);
            Console.ReadLine();
        }
    }
}
